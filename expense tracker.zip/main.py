def add_expense(): #add expenses
        date = input("Enter the date(YYYY-MM-DD): ")
        amount = int(input("Enter the amount spent: "))
        category = input("Enter on what you have spent the money: ")
        description = input("Enter description(optional): ")

        if description.strip() == "":
            expense_line = f'{date} | {amount} | {category}\n'
        else:
            expense_line = f'{date} | {amount} | {category} | {description}\n'

        f = open("add.txt", 'a')
        f.write(expense_line)
        f.close()

        print("Expenses added succesfully!\n")

def view_expenses(): #view expenses
        f = open("add.txt", 'r')
        content = f.read()
        f.close()

        if content.strip() == "":
            print("No content is found!")
        else:
            print("******ALL EXPENSES*****")
            print(content)
            print("_________________________")
            
def show_expenses(): #show expenses

        total = 0 #read from here this 3rd choice
        try:
            f = open("add.txt", 'r')
            for i in f:
                parts = i.strip().split(" | ")
                if len(parts) >= 2:
                    try:
                        total += float(parts[1])
                    except ValueError:
                        continue
            print(f"Total expenses: {total}")
        except FileNotFoundError:
            print("No expenses found!")

while True:
    print("Show menu:")
    print("1.Add expenses")
    print("2.View expenses")
    print("3.Show expenses")
    print("4.Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        add_expense()
    elif choice == "2":
        view_expenses()
    elif choice == "3":
        show_expenses()
    elif choice == "4":
        print("Exiting....")
        break
    else:
        print("Invalid option. Try again.")